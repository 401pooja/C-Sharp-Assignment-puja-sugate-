﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Forum
    {
        
            private long id;
            private string Name;
            private string EmailId;
            private string Dateofbirth;
           

            public Forum()//constructor
            {
                Console.WriteLine("Default constructer of Forum");
            }

            public Forum(long id,string Name, string EmailId, string Dateofbirth)
            {
                this.id = id;
                this.Name = Name;
                this.EmailId= EmailId;
                this.Dateofbirth = Dateofbirth;
                

            }
            public override string ToString()
            {
            return ($"Id={id}" +
                $" \nName={Name} " +
                $"\nEmail id={EmailId} " +
                $"\nDate of birth={Dateofbirth}");
                   
            }

            public static bool CheckduplicatEmail(List<Forum> users ,string email)
            {
            foreach(Forum temp in users )
            {
                if(temp.EmailId==email)
                {
                    return true;
                }
            }
            return false;

            }

        static void Main()
        {
            List<Forum> userlist = new List<Forum>();
            int choice;

            do
            {
                Console.WriteLine("Enter the id");
                int i = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the name");
                string n = Console.ReadLine();

                Console.WriteLine("Enter the emailId");
                string e = Console.ReadLine();

                bool result = CheckduplicatEmail(userlist, e);
                while(result)
                {
                    Console.WriteLine("EmailId is not found");
                    e = Console.ReadLine();
                    result = CheckduplicatEmail(userlist, e);

                }

                Console.WriteLine("Enter the date of birth");
                string d = Console.ReadLine();

                Console.WriteLine();
                Forum f = new Forum(i, n, e, d);
                Console.WriteLine(f.ToString());

                Console.WriteLine("Add more users");
                Console.WriteLine($"1.Add Users:" +
                    $"2.Exit");
                choice= Convert.ToInt32(Console.ReadLine());
                userlist.Add(f);
            } while (choice != 2);










            Console.ReadLine();
        }



    }
}
