﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Hotel
    {
        private int Number;
        private int Floor;
        private string Type;
        private int Capacity;
        private DateTime bookedTime;
        private double price;

        public Hotel()//constructor
        {
            Console.WriteLine("Default constructer of Hotel");
        }

        public Hotel(int Number, int Floor, string Type, int Capacity, DateTime bookedTime, double price)
        {
            this.Number = Number;
            this.Floor = Floor;
            this.Type = Type;
            this.Capacity = Capacity;
            this.bookedTime = bookedTime;
            this.price = price;


        }
        public override string ToString()
        {
            return ($"Room Number={Number}" +
                $" \nFloor Number={Floor} " +
                $"\nRoom Type={Type} " +
                $"\nCapacity={Capacity}" +
                $"\n booked Time={bookedTime}" +
                $"\n price={price}");
        }

    }
}
