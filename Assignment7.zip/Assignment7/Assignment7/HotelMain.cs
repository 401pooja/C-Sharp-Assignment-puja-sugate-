﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class HotelMain
    {

        static void Main()
        {

            Console.WriteLine("Enter the number");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Floor");
            int f = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Type");
            string t = Console.ReadLine();

            Console.WriteLine("Enter the Capacity");
            int c = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the booked time");
            DateTime d = DateTime.Parse(Console.ReadLine());

            Console.WriteLine("Enter the price");
            int p = Convert.ToInt32(Console.ReadLine());

            Hotel h = new Hotel(n, f, t, c, d, p);
            Console.WriteLine(h.ToString());


            Console.ReadLine();
        }


    }
}
