﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    public interface IBankAccount
    {
        void Deposite(double amount);
        void Withdraw(double amount);
    }

    public class SavingAccount : IBankAccount
    {
        double balance = 0;
        public void Deposite(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Saving Amount:{amount}");
            Console.WriteLine($"Balence:{balance}");
            Console.WriteLine();
        }

        public void Withdraw(double amount)
        {
            if(amount<=balance)
            {
                balance = balance - amount;
                Console.WriteLine($"Withdraw Amount:{amount}");
                Console.WriteLine($"Balence:{balance}");
                Console.WriteLine();
            }
            else if(amount<=50000)
            {
                balance = balance - amount;
                Console.WriteLine($"Withdraw Amount:{amount}");
                Console.WriteLine($"Balence:{balance}");
                Console.WriteLine();
            }
            else 
            {
                Console.WriteLine("not  exceed balence");
                Console.WriteLine($"Balence:{balance}");

            }
            
        }
    }

    public class CurrentAccount: IBankAccount
    {
        double balance = 50000;
        public void Deposite(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Saving Amount:{amount}");
            Console.WriteLine($"Balence:{balance}");
            Console.WriteLine();
        }

        public void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance =  amount-balance;
                Console.WriteLine($"Withdraw Amount:{amount}");
                Console.WriteLine($"Balence:{balance}");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("not  exceed balence");
                Console.WriteLine($"Balence:{balance}");

            }

        }

    }

    class MainBank
    {
        static void Main()
        {
            Console.WriteLine("Enter deposite amount");
            double dpt = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter withdraw amount");
            double wthd = Convert.ToInt64(Console.ReadLine());
            SavingAccount sa = new SavingAccount();
            sa.Deposite(dpt);
            sa.Withdraw(wthd);

            CurrentAccount ca = new CurrentAccount();
            ca.Deposite(dpt);
            ca.Withdraw(wthd);













        }
    }
    

}
