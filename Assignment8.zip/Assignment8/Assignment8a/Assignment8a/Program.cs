﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment18;

namespace Assignment8a
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Amount");
            double a = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter Rate");
            double r = Convert.ToInt64(Console.ReadLine());
            Double gst;
            GST1 g = new GST1();
           
            Console.WriteLine($"Total amount with gst:{g.Gst1(a, r)}");
           // Console.WriteLine($"Total gst on {a}:{gst}");

        }
    }
}
