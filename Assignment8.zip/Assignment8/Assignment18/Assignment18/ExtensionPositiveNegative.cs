﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment18
{
    public static class ExtensionPositiveNegative
    {
        public static void IsPositive(this int i,int value)
        {
            if(value>0)
            {
                Console.WriteLine("value is positive{0}", value = value + i);

            }
            else
            {
                Console.WriteLine("Value is negative");
            }
        }

        class MainPositive
        {
            static void Main()
            {
                int i = 5;
                Console.WriteLine("Enter the number");
                int n = Convert.ToInt32(Console.ReadLine());
                 n.IsPositive(i);
                Console.WriteLine($"Number:{n}" +
                    $"value:{i}");

            }
        }

    }
}
