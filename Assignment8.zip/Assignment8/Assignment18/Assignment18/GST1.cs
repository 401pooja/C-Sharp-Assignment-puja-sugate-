﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment18
{
    public class GST1
    {
        public double Gst1(double amount,double rate)
        {
            double Interest = (amount + rate) / 100;
            double TotalAmount = amount + Interest;
            return TotalAmount;
        }
    }
}
